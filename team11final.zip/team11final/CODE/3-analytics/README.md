Behold the future of analytics. 
