cd ~/cse6242-2020-TeamProject/

rm -rf cse6242-2020-TeamProject/

git clone https://github.gatech.edu/jinness3/cse6242-2020-TeamProject.git

cd /home/teamelevenproject/cse6242-2020-TeamProject/cse6242-2020-TeamProject/WebFront

gcloud app deploy
